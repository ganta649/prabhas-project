// import { sendOTP, verifyOTP, resendOTP } from "email-otp-verify";
import { Button, CardContent, Container, FormControl, FormGroup, Grid, Stack, TextField } from "@mui/material"
import { Card } from "react-bootstrap"

function ForgotPassword(){
    return(<div>
    <Container Container="main" maxWidth="xs">
        <Card>
        <h4>Forgot Password</h4>
            <CardContent>
                <Grid>
                    <FormGroup>
                        <FormControl>Enter your Mail-id</FormControl>
                        <TextField type="email" placeholder="Enter your mail-id"></TextField>
                    </FormGroup>
                </Grid>
                <Grid>
                    
                    <Stack direction="column" spacing={4} margin={2}>
                    <Button href="/otpSubmit" variant="contained" type="Submit">Submit</Button>
                    </Stack>
                </Grid>
            </CardContent>
        </Card>
    </Container>

    </div>)
}
export default ForgotPassword