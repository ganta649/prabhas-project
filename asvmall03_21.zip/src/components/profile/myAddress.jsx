
import Grid from '@mui/material/Grid';
import axios from 'axios';
import { useEffect, useState } from 'react';
import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import AddressModal2 from './addressmodel2';
import AddNewAddressModal from './addnewAddressFrom';

const MyAddress = () => {
    const [addresslist, setAddressList] = useState([])
    const [selectedAddress, setSelectedAddress] = useState([]);
    const [updatePage, setUpdatePage] = useState(false)

    const onPageUpdate = () => {

        setUpdatePage(!updatePage)

    }

    useEffect(() => {

        axios.post("http://localhost/asvmall/address/getaddresslist.php", {
            "main_id": "8989877hhftgh67",
            "user_id": localStorage.getItem("userid")
        }).then((result) => {

            if (result.status === 200 && result.request.readyState === 4 && Array.isArray(result.data)) {


                let filteredArr = result.data.filter((eachITem => eachITem.address_isdefault != 0))
                setAddressList(filteredArr)
                setSelectedAddress(result.data.filter((eachITem => eachITem.address_isdefault == 0)));
                // setSelectedAddress(filteredArr[0].address_id);
                // setUserdetails(filteredArr[0])

            }
        }).catch("no")

    }, [updatePage])
    return (
        <Grid container  >
            {/* {selectedAddress.length > 0 && <AddNewAddressModal />} */}


            <Grid item xs={12} >
                <Grid item xs={12} className="pt-3">


                    <h4 >Default Addresses</h4>
                    <AddressModal2 updatepage={onPageUpdate} />
                </Grid>
                <h4>My other Address</h4>

                {addresslist.length > 0 ?
                    <List sx={{ width: '100%', bgcolor: 'background.paper' }}>
                        {
                            addresslist.map((eachItem, index) => (
                                <ListItem alignItems="flex-start" key={eachItem.address_id}>

                                    <ListItemText
                                        primary={<Typography
                                            sx={{ display: 'inline' }}
                                            component="span"
                                            variant="body1"
                                            color="text.primary"
                                        >
                                            {eachItem.address_user_name}  - {eachItem.address_mobile}</Typography>}
                                        secondary={
                                            <React.Fragment>
                                                <Typography
                                                    sx={{ display: 'inline' }}
                                                    component="span"
                                                    variant="body2"
                                                    color="text.primary"
                                                >
                                                    {eachItem.address_line_1}, {eachItem.address_line_2}
                                                    {eachItem.address_city}, {eachItem.address_state}, {eachItem.address_country} - {eachItem.address_zip}
                                                </Typography>

                                            </React.Fragment>
                                        }
                                    />
                                    {/* <Radio
          checked={selectedAddress === eachItem.address_id}
          onChange={() => setSelectedAddress(eachItem.address_id)}
          value="address2"
        /> */}
                                </ListItem>

                            ))
                        }


                    </List>
                    :
                    <Grid item xs={12}  >
                        No Other Address in your profile You can Add New address for you freinds
                    </Grid>
                }
            </Grid>


        </Grid>


    )
}

export default MyAddress;