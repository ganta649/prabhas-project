import { useState } from "react"

const ImageUpload = () =>{
    const [selectedImage, setSelectedImage] = useState("")
    onImageSleect =(e) =>{


    }
    return(
        <div>
            <input  type="file" name="photo" id="fileseelct"/>
            <button type="button" nChange={e=>onImageSleect(e)} ></button>
        </div>
    )
}