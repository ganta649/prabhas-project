import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

export default function PreferrableTimings() {
  return (
    <FormControl>
      <FormLabel id="demo-row-radio-buttons-group-label">Preferrable Timings</FormLabel>
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
      >
        <FormControlLabel value="t1" control={<Radio />} label="6.AM - 10.AM" />
        <FormControlLabel value="t2" control={<Radio />} label="10.AM - 2PM" />
        <FormControlLabel value="t3" control={<Radio />} label="2PM - 6PM" />
        <FormControlLabel value="t4" control={<Radio />} label="6PM - 10PM" />
       
      </RadioGroup>
    </FormControl>
  );
}