import { useEffect, useState } from 'react';
import './categories.css';
import axios from 'axios';
import { useNavigate } from "react-router-dom"
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';

import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    flexGrow:1,
    color: theme.palette.text.secondary,
  }));
const CategoriesPage = () => {
    const navigate = useNavigate();
    const [categories, setCategories] = useState([])
    const [selectedcategoryId, setSelectedcategoryId] = useState(1)
    const [selectedcategories, setSelectedcategories] = useState([])
    const [currentState, setCurrentState] = useState("INITIAL")
    const [selectedIndex, setSelectedIndex] = useState(1);

    const handleListItemClick = (event, index,each) => {
      setSelectedIndex(index);
      onCategoryClick(each)
    };
    const onCategoryClick = (eachCat) => {
        setSelectedcategoryId(eachCat.CategoryID)
        console.log('', eachCat.id)
        getSubCatItems(eachCat.CategoryID);
    }

    const onViewAllProducts = (catId) => {
        navigate(`/productsbySubCatId/${catId}`)
    }

    const getSubCatItems = (catId) => {

        axios.post('http://localhost/asvmall/subcategories.php', {
            "main_id": "8989877hhftgh67",
            "catId": catId
        }).then(result => {
            
            setSelectedcategories(result.data)

        }).catch(e => {
            console.log(e)
        })
    }

    const getTotaldetailsjsx = () => {
        return (<Grid container spacing={1}>
        <Grid item xs={5} sm={3} md={2} >
        <List component="nav" aria-label="Categorys" >
        {categories.map((each) => 
            
              <ListItemButton
              selected={selectedIndex == each.CategoryID}
              onClick={(event) => handleListItemClick(event, each.CategoryID,each)}
              
            >
             
              <ListItemText primary={each.CategoryName} />
            </ListItemButton>
 )}
        
        
      </List>
       
        </Grid>
        <Grid item xs={7} sm={9} md={10} className="d-flex flex-wrap">
      
                    {
                        selectedcategories.map(each =>

                            <div className='sub-cat-div col-12 col-sm-6 col-md-3 col-lg-2' onClick={e => onViewAllProducts(each.SubcatID)}>



                                <img className="sub-cat-images" src={each.subcatimage} />

                                <p className='sub-cat-title'>{each.SubcatName}</p>
                                <button className="btn btn-info"  >View All</button>
                            </div>)}
              
        </Grid>
       
      </Grid>)
     
    }
    
    useEffect(() => {
        setCurrentState('LOADING')
        axios.post("http://localhost/asvmall/categories.php", {
            "main_id": "8989877hhftgh67"

        }).then(
            (result) => {
                setCategories(result.data)
                getSubCatItems(selectedcategoryId)
                setCurrentState('COMPLETE')
            }

        ).catch(
            (error) => {
                console.log(error)
                setCurrentState('FAILED')
            }
        )


    }, [])

    switch (currentState) {
        case 'LOADING':
            return (<div>Loading...</div>);
            break;
        case 'COMPLETE':

            return (getTotaldetailsjsx());
            break;

        case 'FAILED':
            return (<div className="d-flex    justify-content-center text-center">
                <div>


                    <img src="https://t3.ftcdn.net/jpg/06/47/94/56/360_F_647945631_K1enp9zSJLMLKhzxyArhexgP5xLvDcb6.jpg" alt="server error" />
                    <h1>serever disconnected</h1>
                </div>
            </div>);
            break;
        default:
            return (<div>Fetching details...</div>)
    }

}

export default CategoriesPage;