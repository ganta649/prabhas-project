import { useEffect, useState } from 'react'
import axios from 'axios'
import RecipeReviewCard from './products';
import { Box, Grid } from '@mui/material';
import TextField from '@mui/material/TextField';
import SearchIcon from '@mui/icons-material/Search';

import InputBase from '@mui/material/InputBase';
import { styled, alpha } from '@mui/material/styles';
const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  width: '100%',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));

export const ProductListComponent = () => {
const [productsList,setProductsList] = useState([]);
const [seachValue,setSeachValue]= useState("");
 useEffect(()=>{

  axios.post("http://localhost/asvmall/products.php", {
    "main_id":"8989877hhftgh67"

}).then(res=>{
  
  setProductsList(res.data)
}).catch(
e=>{console.log("Error While fetching data",e)}
)
 },[])


    return (
    // <div>
            <Box sx={{ flexGrow: 1 }}>
        {/* <SearchIcon /> */}
              {/* <TextField
          id="filled-search"
          label="Search field"
          type="search"
          // variant="filled"
          onChange={e => setSeachValue(e.target.value)}
        /> */}
                
        <Grid container spacing={2} className="align-items-center">

  
  <Grid item  xs={12} sm={8}md={6} >
    
 <div className="search-bar-div">
  
  <span class="input-group-text" id="basic-addon1"><SearchIcon /></span>
  <input type="search" class="form-control search-bar" placeholder="search here...." 
  aria-label="searchbar" aria-describedby="basic-addon1" onChange={e => setSeachValue(e.target.value)} />


  {/* <input type="search" className='search-bar' placeholder='search here....'  onChange={e => setSeachValue(e.target.value)} /> */}
 </div>
  </Grid>
  <Grid item xs={12} sm={4} md={6}  className="text-success">
      
  Showing {
      productsList.filter( product => product.productName.toLowerCase().includes(seachValue.toLowerCase())).length
   
   } results found
  </Grid>
 
</Grid>
         
      <Grid container spacing={2}>

{
    productsList.filter( product => product.productName.toLowerCase().includes(seachValue.toLowerCase()) || product.productLongDesc.toLowerCase().includes(seachValue.toLowerCase())).map(each =>(
        <Grid item xs={12} sm={6} md={4}  lg={3} xl={2}>
        <RecipeReviewCard productDetails={each} key={each.productID}/>
    </Grid>
    ))
}
</Grid>
</Box>
// </div>
  
)
}