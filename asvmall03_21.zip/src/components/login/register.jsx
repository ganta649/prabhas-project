import * as React from 'react';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import bcrypt from 'bcryptjs'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Copyright(props) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      {'Copyright © '}
      <Link color="inherit" href="https://mui.com/">
        Your Website
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

// TODO remove, this demo shouldn't need to reset the theme.

const defaultTheme = createTheme();

export default function SignUp() {
  const [errorCode, setErrorcode] = React.useState("")
  const navigate = useNavigate();


  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);

    const isValide = validateRegistrationFeilds(data)
    if (isValide) {
      const AsvCustomSalt = '$2a$10$CwTycUXWue0Thq9StjUM0u'

      const hashedPassword = bcrypt.hashSync(data.get('password'), AsvCustomSalt)
      const userDeatailsObj = {
        "main_id": "8989877hhftgh67",
        "user_name": data.get('userName'),
        "user_mail": data.get('email'),
        "user_password": hashedPassword,
        "user_firstName": data.get('firstName'),
        "user_lastName": data.get('lastName'),
        "user_Phone": data.get('mobile'),
        "user_salt": AsvCustomSalt
      }

      axios.post('http://localhost/asvmall/users/addusers.php', userDeatailsObj).then((res) => {

        //if the registration successfull then it will returns 1 from the database so add a flag to check wether it succssfull or not.
        if (res.data === 1) {
          alert("registratered successfull, Please login ")
          navigate('/Profiles')
        } else {
          alert(res.data)
        }

      }).catch((e) => {
        alert(e)
      })
    } else {
      alert("Please provide valid details")
    }
  };

  const validateRegistrationFeilds = (data) => {
    if (data.get('firstName').length < 3) {
      setErrorcode("firstName")
      return false
    } else if (data.get('lastName').length < 3) {
      setErrorcode("lastName")
      return false
    } else if (data.get('userName').length < 3) {
      setErrorcode("userName")
      return false
    }
    else if (data.get('mobile').length != 10) {
      setErrorcode("mobile")
      return false
    } else if (data.get('email').length < 5) {
      setErrorcode("email")
      return false
    } else if (data.get('password').length < 6) {
      setErrorcode("password")
      return false
    } else if (data.get('confirmPassword') !== data.get('password')) {
      setErrorcode("confirmPassword")
      return false
    }
    else {
      setErrorcode("")
      return true

    }
  }


  return (
    <ThemeProvider theme={defaultTheme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >

          <Typography component="h1" variant="h5">
            Sign up
          </Typography>
          <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  autoComplete="given-name"
                  error={errorCode === "firstName"}
                  name="firstName"
                  required
                  fullWidth
                  id="firstName"
                  label="First Name"
                  autoFocus
                  helperText={errorCode === "firstName" ? "Provide valid Name" : false}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="lastName"
                  label="Last Name"
                  name="lastName"
                  autoComplete="family-name"
                  error={errorCode === "lastName"}
                  helperText={errorCode === "lastName" ? "Provide valid Name" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="userName"
                  label="User Name"
                  name="userName"
                  autoComplete="userName"
                  error={errorCode === "userName"}
                  helperText={errorCode === "userName" ? "Provide valid User Name" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  type="number"
                  id="mobile"
                  label="Mobile Number"
                  name="mobile"
                  autoComplete="mobile"
                  error={errorCode === "mobile"}
                  helperText={errorCode === "mobile" ? "Provide Valid Mobile number" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  error={errorCode === "email"}
                  helperText={errorCode === "email" ? "Provide valid email address" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="new-password"
                  error={errorCode === "password"}
                  helperText={errorCode === "password" ? "Password length should greater than 6 charecters" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="confirmPassword"
                  label="confirm password"
                  type="password"
                  id="password"
                  error={errorCode === "confirmPassword"}
                  helperText={errorCode === "confirmPassword" ? "Password doesnot matched with above password" : false}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={<Checkbox value="allowExtraEmails" color="primary" />}
                  label="I want to receive inspiration, marketing promotions and updates via email."
                  error={errorCode === "firstName"}
                  helperText={errorCode === "firstName" ? "incorrect First Name" : false}
                />
              </Grid>
            </Grid>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign Up
            </Button>
            <Grid container justifyContent="flex-end">
              <Grid item>
                <Link href="/Profiles" variant="body2">
                  Already have an account? Sign in
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
        <Copyright sx={{ mt: 5 }} />
      </Container>
    </ThemeProvider>
  );
}